<?php 
	include("conn.php");
	$name      = $_POST['title'];
	$summary = $_POST['summary'];
	$time        = time();
	$sql = "INSERT INTO `test`.`comment` ( `title`, `summary`, `time`) VALUES ('$name', '$summary', $time);";
	$s = mysql_query($sql,$conn);
	if ($s) {
		echo "<script>alert('提交成功！返回首页。');location.href='liuyan.html';</script>";
	}
	
	

?>
<form action="" method="post" align="center">
    		<p>留言标题:<input type="text" name="title" /></p>
    		<p>留言内容:<textarea cols="50" rows="10" id="contactus" name="summary"></textarea>
    			<input type="submit" value="提交">
    			<p><a href="read.php" />查看留言</p>


    	</form>